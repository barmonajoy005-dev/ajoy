#!/system/bin/sh
# انتظر قليلاً قبل تنفيذ الأوامر لضمان اكتمال إقلاع النظام
sleep 30 # يمكن زيادة هذه القيمة إذا لزم الأمر

# الأوامر التي طلبتها
echo "قناة المهووس التقني"
echo "تم تفعيل 120 فريم فري فاير"
am start -a android.intent.action.VIEW -d "null"

# MODDIR=${0%/*} # هذا السطر قد لا يكون ضرورياً إذا لم تستخدم MODDIR لاحقاً

# Execute script by tytydraco and his project ktweak, thanks! 
write() {
	# Bail out if file does not exist
	[[ ! -f "$1" ]] && return 1
	
	# Make file writable in case it is not already
	chmod +w "$1" 2> /dev/null

	# Write the new value and bail if there's an error
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}

# انتظر مدة أطول قبل تطبيق تعديلات Unity لضمان أن اللعبة قد بدأت أو أن النظام مستقر
sleep 60 

####################################
# UnityFix @modulostk [Telegram]
#Report max frequency to unity tasks.
####################################
#write /proc/sys/kernel/sched_lib_name "com.miHoYo., com.activision., UnityMain, libunity.so, libil2cpp.so"
echo "com.miHoYo., com.activision., UnityMain, libunity.so, libil2cpp.so, libfb.so" > /proc/sys/kernel/sched_lib_name
#write /proc/sys/kernel/sched_lib_mask_force 255
echo "240" > /proc/sys/kernel/sched_lib_mask_force

exit 0