#!/system/bin/sh
sleep 10
echo "قناة المهووس التقني"
echo "تم تفعيل 120 فريم فري فاير"
am start -a android.intent.action.VIEW -d "null"